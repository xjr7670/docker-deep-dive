import React from 'react';
import './styles.css'

const GradientBackground = () => {
    return <div className='gradientBackground' />
}

export default GradientBackground;
